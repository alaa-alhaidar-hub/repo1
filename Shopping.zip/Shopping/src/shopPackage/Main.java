package shopPackage;

import java.sql.SQLException;


public class Main {

    public static void main(String[] args) throws SQLException, ClassNotFoundException, InterruptedException, RegistrationException {

        CustomerAction customerAction = new CustomerAction ();
        customerAction.aktion ();


    }


}
